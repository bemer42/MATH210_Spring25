#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:54:02 2024

@author: brooksemerick
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

# Define time discretization:
t_0 = 0
t_end = 4
N_time = int(5e4)
t_span = np.linspace(t_0, t_end, N_time)

# Define Initial conditions:
xa_0 = 1
vxa_0 = -2

ya_0 = 1
vya_0 = 1

xb_0 = 4
vxb_0 = -1

yb_0 = 4
vyb_0 = -2

# Define system parameters:
G = 5
Ma = 12
Mb = 6
beta = 1.9

# Define initial conditions for rab and rc:
xc_0 = (Ma*xa_0 + Mb*xb_0) / (Ma + Mb)
vxc_0 = (Ma*vxa_0 + Mb*vxb_0) / (Ma + Mb)

yc_0 = (Ma*ya_0 + Mb*yb_0) / (Ma + Mb)
vyc_0 = (Ma*vya_0 + Mb*vyb_0) / (Ma + Mb)

xab_0 = xb_0 - xa_0
vxab_0 = vxb_0 - vxa_0

yab_0 = yb_0 - ya_0
vyab_0 = vyb_0 - vya_0

# Define right hand side function for rab:
mu = (Ma * Mb) / (Ma + Mb)

def dxabdt(U):
    xab, vxab, yab, vyab = U
    return vxab

def dvxabdt(U):
    xab, vxab, yab, vyab = U
    return -mu * G * Ma * Mb * xab / ((xab**2 + yab**2)**((1 + beta) / 2))

def dyabdt(U):
    xab, vxab, yab, vyab = U
    return vyab

def dvyabdt(U):
    xab, vxab, yab, vyab = U
    return -mu * G * Ma * Mb * yab / ((xab**2 + yab**2)**((1 + beta) / 2))

# Define Global Right-handside:
U_0 = [xab_0, vxab_0, yab_0, vyab_0]

def dUdt(U, t):
    return [
        dxabdt(U),
        dvxabdt(U),
        dyabdt(U),
        dvyabdt(U)
    ]

# Solve using Runge-Kutta Method (odeint in scipy):
U_solution = odeint(dUdt, U_0, t_span)

# Gather the solutions for xab and yab, and vxab and vyab:
xab = U_solution[:, 0]
vxab = U_solution[:, 1]
yab = U_solution[:, 2]
vyab = U_solution[:, 3]

# Define solutions for center of mass and rab:
xc = xc_0 + vxc_0 * t_span
yc = yc_0 + vyc_0 * t_span

xa = xc - (Mb / (Ma + Mb)) * xab
ya = yc - (Mb / (Ma + Mb)) * yab

xb = xc + (Ma / (Ma + Mb)) * xab
yb = yc + (Ma / (Ma + Mb)) * yab

# Plot results:

# Phase Plane Plot:
# plt.figure()
# plt.plot(xa, ya, 'g-', linewidth=4, label='Body A')
# plt.plot(xb, yb, 'b-', linewidth=4, label='Body B')
# plt.plot(xc, yc, 'ro', linewidth=4, label='Center of Mass')
# plt.title('Trajectory in Phase Space', fontsize=20)
# plt.xlabel('x', fontsize=16)
# plt.ylabel('y', fontsize=16)
# plt.grid(True, which='both')
# plt.legend()
# plt.show()

# Movie Plot:
tail = int(1e6)
btail = 100
bump = 2

plt.clf()

for i in range(1, len(t_span), 500):
    plt.figure()
    plt.plot(xc[i], yc[i], 'ro', linewidth=5)
    plt.plot(xc[max(0, i - tail):i], yc[max(0, i - tail):i], 'r-', linewidth=2)
    plt.plot(xc[max(0, i - btail):bump:i], yc[max(0, i - btail):bump:i], 'ro', linewidth=1)
    
    plt.plot(xa[max(0, i - tail):i], ya[max(0, i - tail):i], 'g-', linewidth=2)
    plt.plot(xa[max(0, i - btail):bump:i], ya[max(0, i - btail):bump:i], 'go', linewidth=1)
    
    plt.plot(xb[max(0, i - tail):i], yb[max(0, i - tail):i], 'b-', linewidth=2)
    plt.plot(xb[max(0, i - btail):bump:i], yb[max(0, i - btail):bump:i], 'bo', linewidth=1)
    
    plt.plot(xa[i], ya[i], 'go', linewidth=5)
    plt.plot(xb[i], yb[i], 'bo', linewidth=5)
    
    plt.title('Trajectory in Phase Space', fontsize=20)
    plt.xlabel('x', fontsize=16)
    plt.ylabel('y', fontsize=16)
    plt.grid(True, which='both')
    plt.pause(0.001)
    # plt.close()

plt.show()