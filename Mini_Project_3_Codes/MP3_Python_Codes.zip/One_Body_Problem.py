#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 00:51:15 2024

@author: brooksemerick
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from matplotlib.animation import FuncAnimation

# Define time discretization
t_0 = 0
t_end = 40
N_time = int(1e5)
t_span = np.linspace(t_0, t_end, N_time)

# Define initial conditions
x_0 = 1
vx_0 = -1
y_0 = 1
vy_0 = 1

# Define system parameters
G = 5
M = 10
beta = 1.9

# Define right-hand side functions
def dxdt(x, vx, y, vy):
    return vx

def dvxdt(x, vx, y, vy):
    return -G * M * x / ((x**2 + y**2)**((1 + beta) / 2))

def dydt(x, vx, y, vy):
    return vy

def dvydt(x, vx, y, vy):
    return -G * M * y / ((x**2 + y**2)**((1 + beta) / 2))

# Define the global right-hand side
def dUdt(t, U):
    x, vx, y, vy = U
    return [dxdt(x, vx, y, vy), 
            dvxdt(x, vx, y, vy), 
            dydt(x, vx, y, vy), 
            dvydt(x, vx, y, vy)]

# Initial conditions array
U_0 = [x_0, vx_0, y_0, vy_0]

# Solve using Runge-Kutta Method (solve_ivp equivalent to ode45)
sol = solve_ivp(dUdt, [t_0, t_end], U_0, t_eval=t_span, method='RK45')

# Gather the solutions for x, y, vx, and vy
x = sol.y[0]
y = sol.y[2]
t = sol.t

# Create figure and axis for animation
fig, ax = plt.subplots()
ax.set_xlim([1.2 * np.min(x), 1.2 * np.max(x)])
ax.set_ylim([1.2 * np.min(y), 1.2 * np.max(y)])
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('Trajectory in Phase Space')

# Plot the stationary body (center)
stationary_body, = ax.plot(0, 0, 'ro', markersize=10)

# Initialize lines for trajectory and tail
line, = ax.plot([], [], 'k-', linewidth=2)  # Full trajectory
tail, = ax.plot([], [], 'go-', linewidth=1) # Short tail

# Initialization function for animation
def init():
    line.set_data([], [])
    tail.set_data([], [])
    return line, tail

# Update function for animation
def update(frame):
    tail_length = 5  # Tail length
    bump_interval = 1  # Tail plotting interval
    
    # Full trajectory up to the current frame
    line.set_data(x[:frame], y[:frame])
    
    # Tail plotting (only recent tail_length points)
    tail.set_data(x[max(0, frame-tail_length):frame:bump_interval], y[max(0, frame-tail_length):frame:bump_interval])
    
    return line, tail

# Create animation
anim = FuncAnimation(fig, update, frames=len(t), init_func=init, blit=True, interval=10)

# Show the animation
plt.show()